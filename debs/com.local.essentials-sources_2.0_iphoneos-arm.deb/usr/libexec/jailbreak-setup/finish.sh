#!/bin/bash
# Installs AppSync Unified + appinst from LukeZGD's repo once Cydia has finished.
export PATH=/usr/bin:/bin:/usr/sbin:/sbin
LOG=/var/mobile/Library/Logs/jailbreak-setup.log; mkdir -p /var/mobile/Library/Logs
PL=/Library/LaunchDaemons/com.local.jailbreak-setup.plist
log(){ echo "$(date) $*" >> $LOG; }
done_(){ rm -f $PL; log "done: $*"; exit 0; }
PKGS=""
for p in ai.akemi.appsyncunified ai.akemi.appinst; do dpkg-query -W -f='${Status}' $p 2>/dev/null | grep -q 'install ok installed' || PKGS="$PKGS $p"; done
[ -z "$PKGS" ] && done_ "already installed"
log "waiting for Cydia to finish, then installing:$PKGS"
for ((i=0; i<120; i++)); do                                 # up to ~20 minutes
  sleep 10
  ps ax | grep -E '[/ ](dpkg|apt-get|apt|cydo)( |$)' >/dev/null && continue
  apt-get -o Acquire::http::Timeout=20 -o Acquire::https::Timeout=20 -o APT::Get::List-Cleanup=0 -o Dir::Etc::SourceList=/etc/apt/sources.list.d/jailbreak-setup.list \
          -o Dir::Etc::SourceParts=/nonexistent update >> $LOG 2>&1 || continue
  if apt-get -y --force-yes install $PKGS >> $LOG 2>&1; then done_ "installed$PKGS"; fi
  grep -q 'Could not get lock' $LOG && continue
done
log "gave up; install AppSync Unified and appinst from LukeZGD's repo in Cydia"; rm -f $PL; exit 1
