(function (global) {
  var babelHelpers = global.babelHelpers = {};
  function _OverloadYield(e, d) {
    this.v = e, this.k = d;
  }
  babelHelpers.OverloadYield = _OverloadYield;
  function _applyDecoratedDescriptor(i, e, r, n, l) {
    var a = {};
    return Object.keys(n).forEach(function (i) {
      a[i] = n[i];
    }), a.enumerable = !!a.enumerable, a.configurable = !!a.configurable, ("value" in a || a.initializer) && (a.writable = !0), a = r.slice().reverse().reduce(function (r, n) {
      return n(i, e, r) || r;
    }, a), l && void 0 !== a.initializer && (a.value = a.initializer ? a.initializer.call(l) : void 0, a.initializer = void 0), void 0 === a.initializer ? (Object.defineProperty(i, e, a), null) : a;
  }
  babelHelpers.applyDecoratedDescriptor = _applyDecoratedDescriptor;
  function applyDecs2311(n, o, i, a, c, u) {
    var s,
      f,
      l,
      p,
      d,
      m,
      h,
      v = Symbol.metadata || Symbol.for("Symbol.metadata"),
      g = Object.defineProperty,
      y = Object.create,
      b = [y(null), y(null)],
      w = o.length;
    function D(e, t, r) {
      return function (o, i) {
        t && (i = o, o = n);
        for (var a = 0; a < e.length; a++) i = e[a].apply(o, r ? [i] : []);
        return r ? i : o;
      };
    }
    function j(e, t, r, n) {
      if ("function" != typeof e && (n || void 0 !== e)) throw new TypeError(t + " must " + (r || "be") + " a function" + (n ? "" : " or undefined"));
      return e;
    }
    function applyDec(e, r, n, o, i, a, c, u, l, p, d) {
      function m(e) {
        if (!d(e)) throw new TypeError("Attempted to access private element on non-instance");
      }
      var h = [].concat(r[0]),
        v = r[3],
        y = !c,
        w = 1 === i,
        E = 3 === i,
        O = 4 === i,
        S = 2 === i;
      function T(t, r, n) {
        return function (o, i) {
          return r && (i = o, o = e), n && n(o), z[t].call(o, i);
        };
      }
      if (!y) {
        var z = {},
          A = [],
          I = E ? "get" : O || w ? "set" : "value";
        if (l ? (p || w ? z = {
          get: babelHelpers.setFunctionName(function () {
            return v(this);
          }, o, "get"),
          set: function (e) {
            r[4](this, e);
          }
        } : z[I] = v, p || babelHelpers.setFunctionName(z[I], o, S ? "" : I)) : p || (z = Object.getOwnPropertyDescriptor(e, o)), !p && !l) {
          if ((f = b[+u][o]) && 7 !== (f ^ i)) throw Error("Decorating two elements with the same name (" + z[I].name + ") is not supported yet");
          b[+u][o] = i < 3 ? 1 : i;
        }
      }
      for (var P = e, k = h.length - 1; k >= 0; k -= n ? 2 : 1) {
        var x = j(h[k], "A decorator", "be", !0),
          F = n ? h[k - 1] : void 0,
          H = {},
          K = {
            kind: ["field", "accessor", "method", "getter", "setter", "class"][i],
            name: o,
            metadata: s,
            addInitializer: function (e, t) {
              if (e.v) throw new TypeError("attempted to call addInitializer after decoration was finished");
              j(t, "An initializer", "be", !0), a.push(t);
            }.bind(null, H)
          };
        if (y) f = x.call(F, P, K), H.v = 1, j(f, "class decorators", "return") && (P = f);else if (K.static = u, K.private = l, f = K.access = {
          has: l ? d.bind() : function (e) {
            return o in e;
          }
        }, O || (f.get = l ? S ? function (e) {
          return m(e), z.value;
        } : T("get", 0, m) : function (e) {
          return e[o];
        }), S || E || (f.set = l ? T("set", 0, m) : function (e, t) {
          e[o] = t;
        }), P = x.call(F, w ? {
          get: z.get,
          set: z.set
        } : z[I], K), H.v = 1, w) {
          if ("object" == typeof P && P) (f = j(P.get, "accessor.get")) && (z.get = f), (f = j(P.set, "accessor.set")) && (z.set = f), (f = j(P.init, "accessor.init")) && A.unshift(f);else if (void 0 !== P) throw new TypeError("accessor decorators must return an object with get, set, or init properties or undefined");
        } else j(P, (p ? "field" : "method") + " decorators", "return") && (p ? A.unshift(P) : z[I] = P);
      }
      return i < 2 && c.push(D(A, u, 1), D(a, u, 0)), p || y || (l ? w ? c.splice(-1, 0, T("get", u), T("set", u)) : c.push(S ? z[I] : j.call.bind(z[I])) : g(e, o, z)), P;
    }
    function E(e) {
      return g(e, v, {
        configurable: !0,
        enumerable: !0,
        value: s
      });
    }
    return void 0 !== u && (s = u[v]), s = y(null == s ? null : s), d = [], m = function (e) {
      e && d.push(D(e));
    }, h = function (t, o) {
      for (var a = 0; a < i.length; a++) {
        var u = i[a],
          s = u[1],
          f = 7 & s;
        if ((8 & s) == t && !f == o) {
          var m = u[2],
            h = !!u[3],
            v = 16 & s;
          applyDec(t ? n : n.prototype, u, v, h ? "#" + m : babelHelpers.toPropertyKey(m), f, f < 2 ? [] : t ? p = p || [] : l = l || [], d, !!t, h, o, t && h ? function (t) {
            return babelHelpers.checkInRHS(t) === n;
          } : c);
        }
      }
    }, h(8, 0), h(0, 0), h(8, 1), h(0, 1), m(l), m(p), f = d, w || E(n), {
      e: f,
      get c() {
        var e = [];
        return w && [E(n = applyDec(n, [o], a, n.name, 5, e)), D(e, 1)];
      }
    };
  }
  babelHelpers.applyDecs2311 = applyDecs2311;
  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  babelHelpers.arrayLikeToArray = _arrayLikeToArray;
  function _arrayWithHoles(r) {
    var t;
    if (Array.isArray(r) && ("undefined" == typeof Symbol || (t = r[Symbol.iterator]) === [][Symbol.iterator]) && (t || !(t = r["@@iterator"]) || t === []["@@iterator"])) return r;
  }
  babelHelpers.arrayWithHoles = _arrayWithHoles;
  function _arrayWithoutHoles(a) {
    if (Array.isArray(a)) return babelHelpers.arrayLikeToArray(a);
  }
  babelHelpers.arrayWithoutHoles = _arrayWithoutHoles;
  function _assertClassBrand(e, t, n) {
    if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
    throw new TypeError("Private element is not present on this object");
  }
  babelHelpers.assertClassBrand = _assertClassBrand;
  function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e;
  }
  babelHelpers.assertThisInitialized = _assertThisInitialized;
  function _asyncGeneratorDelegate(n) {
    var r = {},
      e = !1;
    function pump(r, o) {
      return e = !0, o = new Promise(function (t) {
        t(n[r](o));
      }), {
        done: !1,
        value: new babelHelpers.OverloadYield(o, 1)
      };
    }
    return r["undefined" != typeof Symbol && Symbol.iterator || "@@iterator"] = function () {
      return this;
    }, r.next = function (t) {
      return e ? (e = !1, t) : pump("next", t);
    }, "function" == typeof n.throw && (r.throw = function (t) {
      if (e) throw e = !1, t;
      return pump("throw", t);
    }), "function" == typeof n.return && (r.return = function (t) {
      return e ? (e = !1, t) : pump("return", t);
    }), r;
  }
  babelHelpers.asyncGeneratorDelegate = _asyncGeneratorDelegate;
  function _asyncIterator(r) {
    var n,
      t,
      o,
      e = 2;
    for ("undefined" != typeof Symbol && (t = Symbol.asyncIterator, o = Symbol.iterator); e--;) {
      if (t && null != (n = r[t])) return n.call(r);
      if (o && null != (n = r[o])) return new AsyncFromSyncIterator(n.call(r));
      t = "@@asyncIterator", o = "@@iterator";
    }
    throw new TypeError("Object is not async iterable");
  }
  function AsyncFromSyncIterator(r) {
    function AsyncFromSyncIteratorContinuation(r) {
      if (Object(r) !== r) return Promise.reject(new TypeError(r + " is not an object."));
      var n = r.done;
      return Promise.resolve(r.value).then(function (r) {
        return {
          value: r,
          done: n
        };
      });
    }
    return AsyncFromSyncIterator = function (r) {
      this.s = r, this.n = r.next;
    }, AsyncFromSyncIterator.prototype = {
      s: null,
      n: null,
      next: function () {
        return AsyncFromSyncIteratorContinuation(this.n.apply(this.s, arguments));
      },
      return: function (r) {
        var n = this.s.return;
        return void 0 === n ? Promise.resolve({
          value: r,
          done: !0
        }) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
      },
      throw: function (r) {
        var n = this.s.throw;
        return void 0 === n ? Promise.reject(r) : AsyncFromSyncIteratorContinuation(n.apply(this.s, arguments));
      }
    }, new AsyncFromSyncIterator(r);
  }
  babelHelpers.asyncIterator = _asyncIterator;
  function asyncGeneratorStep(n, t, e, r, o, a, c) {
    try {
      var i = n[a](c),
        u = i.value;
    } catch (n) {
      return void e(n);
    }
    i.done ? t(u) : Promise.resolve(u).then(r, o);
  }
  function _asyncToGenerator(n) {
    return function () {
      var t = this,
        e = arguments;
      return new Promise(function (r, o) {
        var a = n.apply(t, e);
        function _next(n) {
          asyncGeneratorStep(a, r, o, _next, _throw, "next", n);
        }
        function _throw(n) {
          asyncGeneratorStep(a, r, o, _next, _throw, "throw", n);
        }
        _next(void 0);
      });
    };
  }
  babelHelpers.asyncToGenerator = _asyncToGenerator;
  function _awaitAsyncGenerator(r) {
    return new babelHelpers.OverloadYield(r, 0);
  }
  babelHelpers.awaitAsyncGenerator = _awaitAsyncGenerator;
  function _callSpread(a, e, l) {
    return a.apply(e, l);
  }
  babelHelpers.callSpread = _callSpread;
  function _callSuper(e, c, p) {
    return c = babelHelpers.getPrototypeOf(c), babelHelpers.possibleConstructorReturn(e, babelHelpers.isNativeReflectConstruct() ? Reflect.construct(c, p || [], babelHelpers.getPrototypeOf(e).constructor) : c.apply(e, p));
  }
  babelHelpers.callSuper = _callSuper;
  function _checkInRHS(e) {
    if (Object(e) !== e) throw TypeError("right-hand side of 'in' should be an object, got " + (null !== e ? typeof e : "null"));
    return e;
  }
  babelHelpers.checkInRHS = _checkInRHS;
  function _checkPrivateRedeclaration(e, t) {
    if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
  }
  babelHelpers.checkPrivateRedeclaration = _checkPrivateRedeclaration;
  function _classCallCheck(a, n) {
    if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
  }
  babelHelpers.classCallCheck = _classCallCheck;
  function _classNameTDZError(e) {
    throw new ReferenceError('Class "' + e + '" cannot be referenced in computed property keys.');
  }
  babelHelpers.classNameTDZError = _classNameTDZError;
  function _classPrivateFieldGet2(e, r) {
    return e.get(babelHelpers.assertClassBrand(e, r));
  }
  babelHelpers.classPrivateFieldGet2 = _classPrivateFieldGet2;
  function _classPrivateFieldInitSpec(t, i, a) {
    babelHelpers.checkPrivateRedeclaration(t, i), i.set(t, a);
  }
  babelHelpers.classPrivateFieldInitSpec = _classPrivateFieldInitSpec;
  function _classPrivateFieldBase(e, t) {
    if (!{}.hasOwnProperty.call(e, t)) throw new TypeError("attempted to use private field on non-instance");
    return e;
  }
  babelHelpers.classPrivateFieldLooseBase = _classPrivateFieldBase;
  var e = 0;
  function _classPrivateFieldKey(r) {
    return "__private_" + e++ + "_" + r;
  }
  babelHelpers.classPrivateFieldLooseKey = _classPrivateFieldKey;
  function _classPrivateFieldSet2(e, r, s) {
    return e.set(babelHelpers.assertClassBrand(e, r), s), s;
  }
  babelHelpers.classPrivateFieldSet2 = _classPrivateFieldSet2;
  function _classPrivateGetter(t, e, a) {
    return a(babelHelpers.assertClassBrand(t, e));
  }
  babelHelpers.classPrivateGetter = _classPrivateGetter;
  function _classPrivateMethodInitSpec(t, a) {
    babelHelpers.checkPrivateRedeclaration(t, a), a.add(t);
  }
  babelHelpers.classPrivateMethodInitSpec = _classPrivateMethodInitSpec;
  function _classPrivateSetter(t, e, a, s) {
    return e(babelHelpers.assertClassBrand(t, a), s), s;
  }
  babelHelpers.classPrivateSetter = _classPrivateSetter;
  function _classStaticPrivateMethodGet(r, a, e) {
    return babelHelpers.assertClassBrand(a, r), e;
  }
  babelHelpers.classStaticPrivateMethodGet = _classStaticPrivateMethodGet;
  function _construct(e, o, p) {
    if (babelHelpers.isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
    var n = [null];
    n.push.apply(n, o);
    var l = new (e.bind.apply(e, n))();
    return p && babelHelpers.setPrototypeOf(l, p.prototype), l;
  }
  babelHelpers.construct = _construct;
  function _defineProperties(r, t) {
    for (var o = 0; o < t.length; o++) {
      var i = t[o];
      i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, babelHelpers.toPropertyKey(i.key), i);
    }
  }
  function _createClass(e, r, t) {
    return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
      writable: !1
    }), e;
  }
  babelHelpers.createClass = _createClass;
  function _createForOfIteratorHelper(e, t) {
    var n = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (!n) {
      if (Array.isArray(e) || (n = babelHelpers.unsupportedIterableToArray(e)) || t && e && "number" == typeof e.length) {
        n && (e = n);
        var o = 0,
          F = function () {};
        return {
          s: F,
          n: function () {
            return o >= e.length ? {
              done: !0
            } : {
              done: !1,
              value: e[o++]
            };
          },
          e: function (r) {
            throw r;
          },
          f: F
        };
      }
      throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var a,
      u,
      i = !0;
    return {
      s: function () {
        n = n.call(e);
      },
      n: function () {
        i = !0;
        var r = n.next();
        return r.done ? {
          done: !0
        } : {
          value: r.value,
          done: i = !1
        };
      },
      e: function (r) {
        a = !0, u = r;
      },
      f: function () {
        try {
          i || null == n.return || n.return();
        } finally {
          if (a) throw u;
        }
      }
    };
  }
  babelHelpers.createForOfIteratorHelper = _createForOfIteratorHelper;
  function _createForOfIteratorHelperLoose(r, t) {
    var o = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (o) return (o = o.call(r)).next.bind(o);
    if (Array.isArray(r) || (o = babelHelpers.unsupportedIterableToArray(r)) || t && r && "number" == typeof r.length) {
      o && (r = o);
      var n = 0;
      return function () {
        return n >= r.length ? {
          done: !0
        } : {
          done: !1,
          value: r[n++]
        };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  babelHelpers.createForOfIteratorHelperLoose = _createForOfIteratorHelperLoose;
  function _createModuleNsFilter(e) {
    return r => {
      for (var getter = e => () => r[e], t = Object.create(null), n = 0; n < e.length; n++) {
        var o = e[n];
        if (!(o in r)) throw new ReferenceError("The requested module does not provide an export named '" + o + "'");
        o in t || Object.defineProperty(t, o, {
          enumerable: !0,
          get: getter(o)
        });
      }
      return Object.defineProperty(t, Symbol.toStringTag, {
        value: "Module"
      }), Object.freeze(t);
    };
  }
  babelHelpers.createModuleNsFilter = _createModuleNsFilter;
  function _createSuper(o) {
    var i = babelHelpers.isNativeReflectConstruct();
    return function () {
      var r,
        c = babelHelpers.getPrototypeOf(o);
      if (i) {
        var n = babelHelpers.getPrototypeOf(this).constructor;
        r = Reflect.construct(c, arguments, n);
      } else r = c.apply(this, arguments);
      return babelHelpers.possibleConstructorReturn(this, r);
    };
  }
  babelHelpers.createSuper = _createSuper;
  function _defaults(e, r) {
    for (var t = Object.getOwnPropertyNames(r), o = 0; o < t.length; o++) {
      var n = t[o],
        a = Object.getOwnPropertyDescriptor(r, n);
      a && a.configurable && void 0 === e[n] && Object.defineProperty(e, n, a);
    }
    return e;
  }
  babelHelpers.defaults = _defaults;
  function _defineAccessor(e, r, n, t) {
    var c = {
      configurable: !0,
      enumerable: !0
    };
    return c[e] = t, Object.defineProperty(r, n, c);
  }
  babelHelpers.defineAccessor = _defineAccessor;
  function _defineProperty(r, t, o) {
    return (t = babelHelpers.toPropertyKey(t)) in r ? Object.defineProperty(r, t, {
      value: o,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : r[t] = o, r;
  }
  babelHelpers.defineProperty = _defineProperty;
  function _extends() {
    return babelHelpers.extends = _extends = Object.assign ? Object.assign.bind() : function (n) {
      for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
      }
      return n;
    }, _extends.apply(null, arguments);
  }
  babelHelpers.extends = _extends;
  function _filterModuleNamespace(t) {
    var e,
      o = !1;
    try {
      var i = t(function (r) {
        if (Object(r) === r) try {
          var {
            exports: t
          } = r;
          if (void 0 !== t) {
            if (Object(t) !== t) throw new TypeError("import()'s `exports` must be an object");
            for (var i of (e = [], t)) {
              if ("string" != typeof i) throw new TypeError("import()'s `exports` must be strings");
              e.push(i);
            }
          }
        } catch (r) {
          throw o = !0, r;
        }
        return r;
      });
    } catch (r) {
      if (o) return Promise.reject(r);
      throw r;
    }
    return e ? (e.sort(), i.then(babelHelpers.createModuleNsFilter(e))) : i;
  }
  babelHelpers.filterModuleNamespace = _filterModuleNamespace;
  function _get() {
    return babelHelpers.get = _get = "undefined" != typeof Reflect && Reflect.get ? Reflect.get.bind() : function (t, r, n) {
      var l = babelHelpers.superPropBase(t, r);
      if (l) {
        var f = Object.getOwnPropertyDescriptor(l, r);
        return f.get ? f.get.call(arguments.length < 3 ? t : n) : f.value;
      }
    }, _get.apply(null, arguments);
  }
  babelHelpers.get = _get;
  function _getPrototypeOf(t) {
    return babelHelpers.getPrototypeOf = _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
      return t.__proto__ || Object.getPrototypeOf(t);
    }, _getPrototypeOf(t);
  }
  babelHelpers.getPrototypeOf = _getPrototypeOf;
  function _identity(t) {
    return t;
  }
  babelHelpers.identity = _identity;
  function _immutableUint8Array(e) {
    return "buffer" in e && (e = e.buffer.slice(e.byteOffset, e.byteOffset + e.byteLength)), new Uint8Array(e.transferToImmutable ? e.transferToImmutable() : e);
  }
  babelHelpers.immutableUint8Array = _immutableUint8Array;
  function _importDeferProxy(e) {
    var t;
    function r() {
      return !1;
    }
    function n(r) {
      return function (n, o, f) {
        return r(t || (t = e()), o, f);
      };
    }
    return new Proxy({
      __proto__: null
    }, {
      defineProperty: r,
      deleteProperty: r,
      get: n(Reflect.get),
      getOwnPropertyDescriptor: n(Reflect.getOwnPropertyDescriptor),
      isExtensible: r,
      has: n(Reflect.has),
      ownKeys: n(Reflect.ownKeys),
      preventExtensions: function () {
        return !0;
      },
      set: r,
      setPrototypeOf: r
    });
  }
  babelHelpers.importDeferProxy = _importDeferProxy;
  function _inherits(t, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Super expression must either be null or a function");
    t.prototype = Object.create(r && r.prototype, {
      constructor: {
        value: t,
        writable: !0,
        configurable: !0
      }
    }), Object.defineProperty(t, "prototype", {
      writable: !1
    }), r && babelHelpers.setPrototypeOf(t, r);
  }
  babelHelpers.inherits = _inherits;
  function _inheritsLoose(o, e) {
    o.prototype = Object.create(e.prototype), o.prototype.constructor = o, babelHelpers.setPrototypeOf(o, e);
  }
  babelHelpers.inheritsLoose = _inheritsLoose;
  function _initializerDefineProperty(e, i, r, l) {
    r && Object.defineProperty(e, i, {
      enumerable: r.enumerable,
      configurable: r.configurable,
      writable: r.writable,
      value: r.initializer ? r.initializer.call(l) : void 0
    });
  }
  babelHelpers.initializerDefineProperty = _initializerDefineProperty;
  function _initializerWarningHelper(r, e) {
    throw Error("Decorating class property failed. Please ensure that transform-class-properties is enabled and runs after the decorators transform.");
  }
  babelHelpers.initializerWarningHelper = _initializerWarningHelper;
  function _instanceof(n, e) {
    return null != e && "undefined" != typeof Symbol && e[Symbol.hasInstance] ? !!e[Symbol.hasInstance](n) : n instanceof e;
  }
  babelHelpers.instanceof = _instanceof;
  function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
      default: e
    };
  }
  babelHelpers.interopRequireDefault = _interopRequireDefault;
  var _e;
  function _interopRequireWildcard(t, r) {
    if (!r && t && t.__esModule) return t;
    var n,
      a,
      o = Object.defineProperty,
      f = {
        __proto__: null,
        default: t
      };
    if (Object(t) !== t) return f;
    if (_e || "function" != typeof WeakMap || (_e = new WeakMap()), _e) {
      if (_e.has(t)) return _e.get(t);
      _e.set(t, f);
    }
    for (a in t) "default" !== a && {}.hasOwnProperty.call(t, a) && ((n = o && Object.getOwnPropertyDescriptor(t, a)) && (n.get || n.set) ? o(f, a, n) : f[a] = t[a]);
    return f;
  }
  babelHelpers.interopRequireWildcard = _interopRequireWildcard;
  function _isNativeFunction(t) {
    try {
      return -1 !== Function.toString.call(t).indexOf("[native code]");
    } catch (n) {
      return "function" == typeof t;
    }
  }
  babelHelpers.isNativeFunction = _isNativeFunction;
  function _isNativeReflectConstruct() {
    try {
      var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    } catch (t) {}
    return (babelHelpers.isNativeReflectConstruct = _isNativeReflectConstruct = function () {
      return !!t;
    })();
  }
  babelHelpers.isNativeReflectConstruct = _isNativeReflectConstruct;
  function _iterableToArray(r) {
    var e = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (Array.isArray(r) && (null == e || e === ("undefined" != typeof Symbol && [][Symbol.iterator]) || e === []["@@iterator"])) return r;
    if (null != e) {
      for (var t, o = [], a = e.call(r); !(t = a.next()).done;) o.push(t.value);
      return o;
    }
  }
  babelHelpers.iterableToArray = _iterableToArray;
  function _iterableToArrayLimit(r, t) {
    var e = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
    if (Array.isArray(r) && (null == e || e === ("undefined" != typeof Symbol && [][Symbol.iterator]) || e === []["@@iterator"])) return r;
    if (null != e) {
      var l,
        n,
        i,
        a,
        u = [],
        o = !0,
        f = !1;
      try {
        if (i = (e = e.call(r)).next, 0 === t) {
          if (Object(e) !== e) return;
          o = !1;
        } else for (; !(o = (l = i.call(e)).done) && (u.push(l.value), u.length !== t); o = !0);
      } catch (r) {
        f = !0, n = r;
      } finally {
        try {
          if (!o && null != e.return && (a = e.return(), Object(a) !== a)) return;
        } finally {
          if (f) throw n;
        }
      }
      return u;
    }
  }
  babelHelpers.iterableToArrayLimit = _iterableToArrayLimit;
  var _e2;
  function _createRawReactElement(r, o, l, n) {
    _e2 || (_e2 = "function" == typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103);
    var t = r && r.defaultProps,
      f = arguments.length - 3;
    if (o || 0 === f || (o = {
      children: void 0
    }), f > 0) {
      var a = n;
      if (f > 1) {
        a = Array(f);
        for (var i = 0; i < f; i++) a[i] = arguments[i + 3];
      }
      o.children = a;
    }
    if (o && t) for (var u in t) void 0 === o[u] && (o[u] = t[u]);else o || (o = t || {});
    return {
      $$typeof: _e2,
      type: r,
      key: void 0 === l ? null : "" + l,
      ref: null,
      props: o,
      _owner: null
    };
  }
  babelHelpers.jsx = _createRawReactElement;
  function _maybeArrayLike(e, a, t) {
    if (a && !Array.isArray(a) && "number" == typeof a.length) {
      var i = a.length;
      return babelHelpers.arrayLikeToArray(a, void 0 !== t && t < i ? t : i);
    }
    return e(a, t);
  }
  babelHelpers.maybeArrayLike = _maybeArrayLike;
  function _newArrowCheck(n, r) {
    if (n !== r) throw new TypeError("Cannot instantiate an arrow function");
  }
  babelHelpers.newArrowCheck = _newArrowCheck;
  function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  babelHelpers.nonIterableRest = _nonIterableRest;
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  babelHelpers.nonIterableSpread = _nonIterableSpread;
  function _nullishReceiverError(r) {
    throw new TypeError("Cannot set property of null or undefined.");
  }
  babelHelpers.nullishReceiverError = _nullishReceiverError;
  function _objectDestructuringEmpty(t) {
    if (null == t) throw new TypeError("Cannot destructure " + t);
  }
  babelHelpers.objectDestructuringEmpty = _objectDestructuringEmpty;
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(r) {
    for (var t = 1; t < arguments.length; t++) {
      var o = null != arguments[t] ? arguments[t] : {};
      t % 2 ? ownKeys(Object(o), !0).forEach(function (t) {
        babelHelpers.defineProperty(r, t, o[t]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(o)) : ownKeys(Object(o)).forEach(function (e) {
        Object.defineProperty(r, e, Object.getOwnPropertyDescriptor(o, e));
      });
    }
    return r;
  }
  babelHelpers.objectSpread2 = _objectSpread2;
  function _objectWithoutProperties(t, r) {
    if (null == t) return {};
    var o,
      n,
      i = babelHelpers.objectWithoutPropertiesLoose(t, r);
    if (Object.getOwnPropertySymbols) {
      var l = Object.getOwnPropertySymbols(t);
      for (n = 0; n < l.length; n++) o = l[n], -1 === r.indexOf(o) && {}.propertyIsEnumerable.call(t, o) && (i[o] = t[o]);
    }
    return i;
  }
  babelHelpers.objectWithoutProperties = _objectWithoutProperties;
  function _objectWithoutPropertiesLoose(r, e) {
    if (null == r) return {};
    var t = {};
    for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
      if (-1 !== e.indexOf(n)) continue;
      t[n] = r[n];
    }
    return t;
  }
  babelHelpers.objectWithoutPropertiesLoose = _objectWithoutPropertiesLoose;
  function _possibleConstructorReturn(t, e) {
    if (e && ("object" == typeof e || "function" == typeof e)) return e;
    if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
    return babelHelpers.assertThisInitialized(t);
  }
  babelHelpers.possibleConstructorReturn = _possibleConstructorReturn;
  function _processResponse(t, e, r) {
    return t.then(function (t) {
      if (t.ok) return t = t[e](), r ? t.then(r) : t;
      throw TypeError("Fetch failed: " + t.status + " " + t.statusText);
    });
  }
  babelHelpers.processResponse = _processResponse;
  function _readOnlyError(r) {
    throw new TypeError('"' + r + '" is read-only');
  }
  babelHelpers.readOnlyError = _readOnlyError;
  function _regenerator() {
    /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */
    var r,
      e,
      o = "function" == typeof Symbol ? Symbol : {},
      n = o.iterator || "@@iterator",
      a = o.toStringTag || "@@toStringTag";
    function i(o, n, a, i) {
      var u = n && n.prototype instanceof Generator ? n : Generator,
        f = Object.create(u.prototype);
      return babelHelpers.regeneratorDefine(f, "_invoke", function (t, o, n) {
        var a,
          i,
          u,
          f = 0,
          p = n || [],
          y = !1,
          G = {
            p: 0,
            n: 0,
            v: r,
            a: l,
            f: l.bind(r, 4),
            d: function (t, e) {
              return a = t, i = 0, u = r, G.n = e, c;
            }
          };
        function l(t, o) {
          for (i = t, u = o, e = 0; !y && f && !n && e < p.length; e++) {
            var n,
              a = p[e],
              l = G.p,
              F = a[2];
            t > 3 ? (n = F === o) && (u = a[(i = a[4]) ? 5 : (i = 3, 3)], a[4] = a[5] = r) : a[0] <= l && ((n = t < 2 && l < a[1]) ? (i = 0, G.v = o, G.n = a[1]) : l < F && (n = t < 3 || a[0] > o || o > F) && (a[4] = t, a[5] = o, G.n = F, i = 0));
          }
          if (n || t > 1) return c;
          throw y = !0, o;
        }
        return function (n, p, F) {
          if (f > 1) throw TypeError("Generator is already running");
          for (y && 1 === p && l(p, F), i = p, u = F; (e = i < 2 ? r : u) || !y;) {
            a || (i ? (i > 1 && (G.n = i < 3 ? -1 : u), l(i, u)) : G.v = u);
            try {
              if (f = 2, a) {
                if (i || (n = "next"), e = a[n]) {
                  if (!(e = e.call(a, u))) throw TypeError("iterator result is not an object");
                  if (!e.done) return e;
                  u = e.value, i < 2 && (i = 0);
                } else 1 === i && (e = a.return) && e.call(a), i < 2 && (u = TypeError("The iterator does not provide a '" + n + "' method"), i = 1);
                a = r;
              } else if ((e = (y = G.n < 0) ? u : t.call(o, G)) !== c) break;
            } catch (t) {
              a = r, i = 1, u = t;
            } finally {
              f = 1;
            }
          }
          return {
            value: e,
            done: y
          };
        };
      }(o, a, i), !0), f;
    }
    var c = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    e = Object.getPrototypeOf;
    var u = [][n] ? e(e([][n]())) : (babelHelpers.regeneratorDefine(e = {}, n, function () {
        return this;
      }), e),
      f = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(u);
    function p(r) {
      return Object.setPrototypeOf ? Object.setPrototypeOf(r, GeneratorFunctionPrototype) : (r.__proto__ = GeneratorFunctionPrototype, babelHelpers.regeneratorDefine(r, a, "GeneratorFunction")), r.prototype = Object.create(f), r;
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, babelHelpers.regeneratorDefine(f, "constructor", GeneratorFunctionPrototype), babelHelpers.regeneratorDefine(GeneratorFunctionPrototype, "constructor", GeneratorFunction), GeneratorFunction.displayName = "GeneratorFunction", babelHelpers.regeneratorDefine(GeneratorFunctionPrototype, a, "GeneratorFunction"), babelHelpers.regeneratorDefine(f), babelHelpers.regeneratorDefine(f, a, "Generator"), babelHelpers.regeneratorDefine(f, n, function () {
      return this;
    }), babelHelpers.regeneratorDefine(f, "toString", function () {
      return "[object Generator]";
    }), (babelHelpers.regenerator = _regenerator = function () {
      return {
        w: i,
        m: p
      };
    })();
  }
  babelHelpers.regenerator = _regenerator;
  function _regeneratorAsync(n, r, t, o, u) {
    var a = babelHelpers.regeneratorAsyncGen(n, r, t, o, u);
    return a.next().then(function (e) {
      return e.done ? e.value : a.next();
    });
  }
  babelHelpers.regeneratorAsync = _regeneratorAsync;
  function _regeneratorAsyncGen(o, t, n, a, m) {
    return new babelHelpers.regeneratorAsyncIterator(babelHelpers.regenerator().w(o, t, n, a), m || Promise);
  }
  babelHelpers.regeneratorAsyncGen = _regeneratorAsyncGen;
  function AsyncIterator(r, e) {
    function o(n, i, c, u) {
      try {
        var f = r[n](i),
          a = f.value;
        return a instanceof babelHelpers.OverloadYield ? e.resolve(a.v).then(function (t) {
          o("next", t, c, u);
        }, function (t) {
          o("throw", t, c, u);
        }) : e.resolve(a).then(function (t) {
          f.value = t, c(f);
        }, function (t) {
          return o("throw", t, c, u);
        });
      } catch (t) {
        u(t);
      }
    }
    var i;
    this.next || (babelHelpers.regeneratorDefine(AsyncIterator.prototype), babelHelpers.regeneratorDefine(AsyncIterator.prototype, "function" == typeof Symbol && Symbol.asyncIterator || "@asyncIterator", function () {
      return this;
    })), babelHelpers.regeneratorDefine(this, "_invoke", function (t, n, r) {
      function c() {
        return new e(function (n, e) {
          o(t, r, n, e);
        });
      }
      return i = i ? i.then(c, c) : c();
    }, !0);
  }
  babelHelpers.regeneratorAsyncIterator = AsyncIterator;
  function regeneratorDefine(e, r, n, t) {
    var i = Object.defineProperty;
    try {
      i({}, "", {});
    } catch (e) {
      i = 0;
    }
    babelHelpers.regeneratorDefine = regeneratorDefine = function (e, r, n, t) {
      function o(r, n) {
        regeneratorDefine(e, r, function (e) {
          return this._invoke(r, n, e);
        });
      }
      r ? i ? i(e, r, {
        value: n,
        enumerable: !t,
        configurable: !t,
        writable: !t
      }) : e[r] = n : (o("next", 0), o("throw", 1), o("return", 2));
    }, regeneratorDefine(e, r, n, t);
  }
  babelHelpers.regeneratorDefine = regeneratorDefine;
  function _regeneratorKeys(e) {
    var n = Object(e),
      r = [];
    for (var t in n) r.unshift(t);
    return function e() {
      for (; r.length;) if ((t = r.pop()) in n) return e.value = t, e.done = !1, e;
      return e.done = !0, e;
    };
  }
  babelHelpers.regeneratorKeys = _regeneratorKeys;
  function _regeneratorValues(e) {
    if (null != e) {
      var t = e["function" == typeof Symbol && Symbol.iterator || "@@iterator"],
        r = 0;
      if (t) return t.call(e);
      if ("function" == typeof e.next) return e;
      if (!isNaN(e.length)) return {
        next: function () {
          return e && r >= e.length && (e = void 0), {
            value: e && e[r++],
            done: !e
          };
        }
      };
    }
    throw new TypeError(typeof e + " is not iterable");
  }
  babelHelpers.regeneratorValues = _regeneratorValues;
  function set(r, f, o, i) {
    return set = "undefined" != typeof Reflect && Reflect.set ? Reflect.set : function (r, f, o, i) {
      var n,
        p = babelHelpers.superPropBase(r, f);
      if (p) {
        if ((n = Object.getOwnPropertyDescriptor(p, f)).set) return n.set.call(i, o), !0;
        if (!n.writable) return !1;
      }
      if (n = Object.getOwnPropertyDescriptor(i, f)) {
        if (!n.writable) return !1;
        n.value = o, Object.defineProperty(i, f, n);
      } else babelHelpers.defineProperty(i, f, o);
      return !0;
    }, set(r, f, o, i);
  }
  function _set(e, t, r, f, o) {
    if (!set(e, t, r, f || e) && o) throw new TypeError("failed to set property");
    return r;
  }
  babelHelpers.set = _set;
  function setFunctionName(e, t, n) {
    "symbol" == typeof t && (t = (t = t.description) ? "[" + t + "]" : "");
    try {
      Object.defineProperty(e, "name", {
        configurable: !0,
        value: n ? n + " " + t : t
      });
    } catch (e) {}
    return e;
  }
  babelHelpers.setFunctionName = setFunctionName;
  function _setPrototypeOf(t, e) {
    return babelHelpers.setPrototypeOf = _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
      return t.__proto__ = e, t;
    }, _setPrototypeOf(t, e);
  }
  babelHelpers.setPrototypeOf = _setPrototypeOf;
  function _skipFirstGeneratorNext(t) {
    return function () {
      var r = t.apply(this, arguments);
      return r.next(), r;
    };
  }
  babelHelpers.skipFirstGeneratorNext = _skipFirstGeneratorNext;
  function _slicedToArray(e, i) {
    return babelHelpers.iterableToArrayLimit(e, i) || babelHelpers.unsupportedIterableToArray(e, i) || babelHelpers.nonIterableRest();
  }
  babelHelpers.slicedToArray = _slicedToArray;
  function _superPropBase(o, t) {
    for (; !{}.hasOwnProperty.call(o, t) && null !== (o = babelHelpers.getPrototypeOf(o)););
    return o;
  }
  babelHelpers.superPropBase = _superPropBase;
  function _superPropGet(r, e, p, f) {
    var n = babelHelpers.get(babelHelpers.getPrototypeOf(1 & f ? r.prototype : r), e, p);
    return 2 & f && "function" == typeof n ? function (t) {
      return n.apply(p, t);
    } : n;
  }
  babelHelpers.superPropGet = _superPropGet;
  function _superPropSet(r, e, p, f, m, u) {
    return babelHelpers.set(babelHelpers.getPrototypeOf(u ? r.prototype : r), e, p, f, m);
  }
  babelHelpers.superPropSet = _superPropSet;
  function _taggedTemplateLiteral(e, t) {
    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
      raw: {
        value: Object.freeze(t)
      }
    }));
  }
  babelHelpers.taggedTemplateLiteral = _taggedTemplateLiteral;
  function _taggedTemplateLiteralLoose(e, t) {
    return t || (t = e.slice(0)), e.raw = t, e;
  }
  babelHelpers.taggedTemplateLiteralLoose = _taggedTemplateLiteralLoose;
  function _tdzError(e) {
    throw new ReferenceError(e + " is not defined - temporal dead zone");
  }
  babelHelpers.tdz = _tdzError;
  function _temporalRef(e, o) {
    return e === babelHelpers.temporalUndefined ? babelHelpers.tdz(o) : e;
  }
  babelHelpers.temporalRef = _temporalRef;
  function _temporalUndefined() {}
  babelHelpers.temporalUndefined = _temporalUndefined;
  function _toArray(e) {
    return babelHelpers.iterableToArray(e) || babelHelpers.unsupportedIterableToArray(e) || babelHelpers.nonIterableRest();
  }
  babelHelpers.toArray = _toArray;
  function _toConsumableArray(a) {
    return babelHelpers.arrayWithoutHoles(a) || babelHelpers.iterableToArray(a) || babelHelpers.unsupportedIterableToArray(a) || babelHelpers.nonIterableSpread();
  }
  babelHelpers.toConsumableArray = _toConsumableArray;
  function toPrimitive(t, e) {
    if ("object" != typeof t || !t) return t;
    var r;
    if ("undefined" != typeof Symbol && void 0 !== (r = t[Symbol.toPrimitive])) {
      var i = r.call(t, e || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === e ? String : Number)(t);
  }
  babelHelpers.toPrimitive = toPrimitive;
  function toPropertyKey(r) {
    var o = babelHelpers.toPrimitive(r, "string");
    return "symbol" == typeof o ? o : o + "";
  }
  babelHelpers.toPropertyKey = toPropertyKey;
  function _toSetter(t, e, n) {
    e || (e = []);
    var r = e.length++;
    return Object.defineProperty({}, "_", {
      set: function (o) {
        e[r] = o, t.apply(n, e);
      }
    });
  }
  babelHelpers.toSetter = _toSetter;
  function tsRewriteRelativeImportExtensions(t, e) {
    return "string" == typeof t && /^\.\.?\//.test(t) ? t.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+)?)\.([cm]?)ts$/i, function (t, s, r, n, o) {
      return s ? e ? ".jsx" : ".js" : !r || n && o ? r + n + "." + o.toLowerCase() + "js" : t;
    }) : t;
  }
  babelHelpers.tsRewriteRelativeImportExtensions = tsRewriteRelativeImportExtensions;
  function _typeof(o) {
    "@babel/helpers - typeof";

    return babelHelpers.typeof = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
      return typeof o;
    } : function (o) {
      return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
    }, _typeof(o);
  }
  babelHelpers.typeof = _typeof;
  function _unsupportedIterableToArray(t, e) {
    if (t) {
      if ("string" == typeof t) return babelHelpers.arrayLikeToArray(t, e);
      var o = {}.toString.call(t).slice(8, -1);
      return "Object" === o && t.constructor && (o = t.constructor.name), "Map" === o || "Set" === o ? Array.from(t) : "Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o) ? babelHelpers.arrayLikeToArray(t, e) : void 0;
    }
  }
  babelHelpers.unsupportedIterableToArray = _unsupportedIterableToArray;
  function _usingCtx() {
    var r = "function" == typeof SuppressedError ? SuppressedError : function (r, e) {
        var n = Error();
        return n.name = "SuppressedError", n.error = r, n.suppressed = e, n;
      },
      e = {},
      n = [];
    function using(r, e) {
      if (null != e) {
        if (Object(e) !== e) throw new TypeError("using declarations can only be used with objects, functions, null, or undefined.");
        if (r) var o = e[Symbol.asyncDispose || Symbol.for("Symbol.asyncDispose")];
        if (void 0 === o && (o = e[Symbol.dispose || Symbol.for("Symbol.dispose")], r)) var t = o;
        if ("function" != typeof o) throw new TypeError("Object is not disposable.");
        t && (o = function () {
          try {
            t.call(e);
          } catch (r) {
            return Promise.reject(r);
          }
        }), n.push({
          v: e,
          d: o,
          a: r
        });
      } else r && n.push({
        d: e,
        a: r
      });
      return e;
    }
    return {
      e: e,
      u: using.bind(null, !1),
      a: using.bind(null, !0),
      d: function () {
        var o,
          t = this.e,
          s = 0;
        function next() {
          for (; o = n.pop();) try {
            if (!o.a && 1 === s) return s = 0, n.push(o), Promise.resolve().then(next);
            if (o.d) {
              var r = o.d.call(o.v);
              if (o.a) return s |= 2, Promise.resolve(r).then(next, err);
            } else s |= 1;
          } catch (r) {
            return err(r);
          }
          if (1 === s) return t !== e ? Promise.reject(t) : Promise.resolve();
          if (t !== e) throw t;
        }
        function err(n) {
          return t = t !== e ? new r(n, t) : n, next();
        }
        return next();
      }
    };
  }
  babelHelpers.usingCtx = _usingCtx;
  function _wrapAsyncGenerator(e) {
    return function () {
      return new AsyncGenerator(e.apply(this, arguments));
    };
  }
  function AsyncGenerator(t) {
    var n, r;
    function resume(n, r) {
      try {
        var o = t[n](r),
          u = o.value,
          i = u instanceof babelHelpers.OverloadYield;
        Promise.resolve(i ? u.v : u).then(function (e) {
          if (i) {
            var r = "return" === n && u.k ? n : "next";
            if (!u.k || e.done) return resume(r, e);
            e = t[r](e).value;
          }
          settle(!!o.done, e);
        }, function (e) {
          resume("throw", e);
        });
      } catch (e) {
        settle(2, e);
      }
    }
    function settle(e, t) {
      2 === e ? n.reject(t) : n.resolve({
        value: t,
        done: e
      }), (n = n.next) ? resume(n.key, n.arg) : r = null;
    }
    this._invoke = function (e, t) {
      return new Promise(function (o, u) {
        var i = {
          key: e,
          arg: t,
          resolve: o,
          reject: u,
          next: null
        };
        r ? r = r.next = i : (n = r = i, resume(e, t));
      });
    }, "function" != typeof t.return && (this.return = void 0);
  }
  AsyncGenerator.prototype["function" == typeof Symbol && Symbol.asyncIterator || "@@asyncIterator"] = function () {
    return this;
  }, AsyncGenerator.prototype.next = function (e) {
    return this._invoke("next", e);
  }, AsyncGenerator.prototype.throw = function (e) {
    return this._invoke("throw", e);
  }, AsyncGenerator.prototype.return = function (e) {
    return this._invoke("return", e);
  };
  babelHelpers.wrapAsyncGenerator = _wrapAsyncGenerator;
  function _wrapNativeSuper(p) {
    var n = "function" == typeof Map ? new Map() : void 0;
    return babelHelpers.wrapNativeSuper = _wrapNativeSuper = function (p) {
      if (null === p || !babelHelpers.isNativeFunction(p)) return p;
      if ("function" != typeof p) throw new TypeError("Super expression must either be null or a function");
      if (void 0 !== n) {
        if (n.has(p)) return n.get(p);
        n.set(p, Wrapper);
      }
      function Wrapper() {
        return babelHelpers.construct(p, arguments, babelHelpers.getPrototypeOf(this).constructor);
      }
      return Wrapper.prototype = Object.create(p.prototype, {
        constructor: {
          value: Wrapper,
          enumerable: !1,
          writable: !0,
          configurable: !0
        }
      }), babelHelpers.setPrototypeOf(Wrapper, p);
    }, _wrapNativeSuper(p);
  }
  babelHelpers.wrapNativeSuper = _wrapNativeSuper;
  function _wrapRegExp() {
    babelHelpers.wrapRegExp = _wrapRegExp = function (e, r) {
      return new BabelRegExp(e, void 0, r);
    };
    var t = RegExp.prototype,
      p = new WeakMap();
    function BabelRegExp(r, t, o) {
      var n = RegExp(r, t);
      return p.set(n, o || p.get(r)), babelHelpers.setPrototypeOf(n, BabelRegExp.prototype);
    }
    function buildGroups(e, r) {
      var t = p.get(r);
      return Object.keys(t).reduce(function (r, p) {
        var o = t[p];
        if ("number" == typeof o) r[p] = e[o];else {
          for (var n = 0; void 0 === e[o[n]] && n + 1 < o.length;) n++;
          r[p] = e[o[n]];
        }
        return r;
      }, Object.create(null));
    }
    return babelHelpers.inherits(BabelRegExp, RegExp), BabelRegExp.prototype.exec = function (e) {
      var r = t.exec.call(this, e);
      if (r) {
        r.groups = buildGroups(r, this);
        var p = r.indices;
        p && (p.groups = buildGroups(p, this));
      }
      return r;
    }, BabelRegExp.prototype[Symbol.replace] = function (e, r) {
      if ("string" == typeof r) {
        var o = p.get(this);
        return t[Symbol.replace].call(this, e, r.replace(/\$<([^>]+)(>|$)/g, function (e, r, t) {
          if ("" === t) return e;
          var p = o[r];
          return Array.isArray(p) ? "$" + p.join("$") : "number" == typeof p ? "$" + p : "";
        }));
      }
      if ("function" == typeof r) {
        var n = this;
        return t[Symbol.replace].call(this, e, function () {
          var e = arguments;
          return "object" != typeof e[e.length - 1] && (e = [].slice.call(e)).push(buildGroups(e, n)), r.apply(this, e);
        });
      }
      return t[Symbol.replace].call(this, e, r);
    }, _wrapRegExp.apply(this, arguments);
  }
  babelHelpers.wrapRegExp = _wrapRegExp;
  function _writeOnlyError(r) {
    throw new TypeError('"' + r + '" is write-only');
  }
  babelHelpers.writeOnlyError = _writeOnlyError;
})(typeof global === "undefined" ? self : global);